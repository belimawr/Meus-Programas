public class Server_chat
{
	public static void main(String[] ss)
	{
		Servidor s = new Servidor(2010);
		s.Execute();
	}
}
